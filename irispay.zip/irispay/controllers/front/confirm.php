<?php
/**
 * Confirmation controller — IRIS Pay redirects here after payment.
 * successUrl: /module/irispay/confirm?status=success
 * errorUrl:   /module/irispay/confirm?status=error
 *
 * The actual order is created by the webhook controller (server-to-server).
 * This controller just shows the result to the customer.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class IrisPayConfirmModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $status = Tools::getValue('status', 'error');
        $cart = $this->context->cart;
        // Prefer explicit cart_id from URL (passed by payment.php) because
        // PrestaShop may clear the session cart after order creation
        $cartId = (int) Tools::getValue('cart_id', $cart->id);



        if ($status === 'success') {
            // Order may already be created by the webhook — look it up
            $id_order = Order::getIdByCartId($cartId);

            if ($id_order) {
                // Order exists — redirect to standard confirmation page
                $order = new Order((int) $id_order);
                // Load customer from ORDER — cart session may be cleared after order creation
                $orderCustomer = new Customer((int) $order->id_customer);
                Tools::redirect(
                    $this->context->link->getPageLink(
                        'order-confirmation',
                        true,
                        null,
                        [
                            'id_cart' => $cartId,
                            'id_module' => (int) $this->module->id,
                            'id_order' => (int) $order->id,
                            'key' => $orderCustomer->secure_key,
                        ]
                    )
                );
            }

            // If we are here, order does not exist yet.
            // Webhook may not have arrived yet — aggressively check status ourselves
            $hookHash = Configuration::get('IRISPAY_HOOK_' . $cartId);
            PrestaShopLogger::addLog("IRIS Pay Confirm: Cart $cartId has hookHash $hookHash", 1);

            if ($hookHash) {
                $irisStatus = $this->module->getPaymentStatus($hookHash);
                PrestaShopLogger::addLog("IRIS Pay Confirm: Retrieved status from API: " . print_r($irisStatus, true), 1);

                if ($irisStatus === 'CONFIRMED') {
                    // Create order right now instead of waiting for webhook
                    $customer = new Customer($cart->id_customer);
                    try {
                        $this->module->validateOrder(
                            $cartId,
                            Configuration::get('PS_OS_PAYMENT'),
                            (float) $cart->getOrderTotal(true, Cart::BOTH),
                            $this->module->displayName,
                            null,
                            ['transaction_id' => '', 'iris_status' => $irisStatus, 'iris_source' => 'redirect_fallback'],
                            (int) $cart->id_currency,
                            false,
                            $cart->secure_key
                        );
                        PrestaShopLogger::addLog("IRIS Pay Confirm: validateOrder succeeded for Cart $cartId", 1);
                    } catch (Exception $e) {
                        PrestaShopLogger::addLog("IRIS Pay Confirm Error: " . $e->getMessage(), 3);
                    }
                    Configuration::deleteByName('IRISPAY_HOOK_' . $cartId);

                    // Registration complete, now redirect
                    Tools::redirect($this->context->link->getPageLink('order-confirmation', true, null, [
                        'id_cart' => $cartId,
                        'id_module' => (int) $this->module->id,
                        'id_order' => (int) $this->module->currentOrder,
                        'key' => $customer->secure_key,
                    ]));
                }
            }

            // If not CONFIRMED yet (e.g. pending/waiting), show holding page
            $this->context->smarty->assign([
                'irispay_pending' => true,
                'shop_name' => $this->context->shop->name,
            ]);
            $this->setTemplate('module:irispay/views/templates/front/pending.tpl');

        } else {
            $this->context->smarty->assign([
                'error' => $this->module->l('Payment failed or was cancelled. Please try again.'),
            ]);
            $this->setTemplate('module:irispay/views/templates/front/error.tpl');
        }
    }
}
