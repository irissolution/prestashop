<?php
/**
 * Payment controller — displays the IRIS Pay iframe via Smarty template
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class IrisPayPaymentModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();

        $cart = $this->context->cart;

        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
            return;
        }

        // Check if payment module is available for this customer/address
        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'irispay') {
                $authorized = true;
                break;
            }
        }
        if (!$authorized) {
            die($this->module->l('This payment method is not available.', 'payment'));
        }

        // If this cart already has a completed order, go straight to confirmation
        $id_order = Order::getIdByCartId((int) $cart->id);
        if ($id_order) {
            $order = new Order((int) $id_order);
            // Load customer from the ORDER — cart session may be cleared by PrestaShop
            $orderCustomer = new Customer((int) $order->id_customer);
            Tools::redirect($this->context->link->getPageLink('order-confirmation', true, null, [
                'id_cart' => (int) $cart->id,
                'id_module' => (int) $this->module->id,
                'id_order' => (int) $order->id,
                'key' => $orderCustomer->secure_key,
            ]));
            return;
        }

        // ---- Prepare URLs -----------------------------------------------
        $cartId = (int) $cart->id;
        $webhookUrl = $this->context->link->getModuleLink('irispay', 'webhook', ['state' => 'cart_' . $cartId], true);

        // ---- Build payment params structure (As per HTML spec) --------------
        $currency = new Currency($cart->id_currency);
        $total = (float) $cart->getOrderTotal(true, Cart::BOTH);

        // ---- Fetch hookHash from IRIS API --------------------------------
        $hookData = $this->module->getHookHash(
            $currency->iso_code,
            $cartId,
            $cartId,
            $total,
            $webhookUrl
        );

        if (!$hookData || !isset($hookData['hookHash'])) {
            $this->context->smarty->assign(['error' => $this->module->l('Could not initialize IRIS Pay payment. Please try again.')]);
            $this->setTemplate('module:irispay/views/templates/front/error.tpl');
            return;
        }

        $hookHash = $hookData['hookHash'];
        $publicHash = $hookData['publicHash'];
        $toIban = $hookData['iban'];
        $merchant = $hookData['merchantName'];

        // ---- Fetch userHash from IRIS API --------------------------------
        $userHash = $this->module->getUserHash($publicHash);
        if (!$userHash) {
            $this->context->smarty->assign(['error' => $this->module->l('Could not connect to IRIS Pay. Please try again.')]);
            $this->setTemplate('module:irispay/views/templates/front/error.tpl');
            return;
        }

        // IMPORTANT: Save the hookHash to verify it in the webhook/status later
        Configuration::updateValue('IRISPAY_HOOK_' . $cartId, $hookHash);

        $paymentData = [
            'currency' => $currency->iso_code,
            'description' => (string) $cartId,
            'sum' => $total,
            'toIban' => $toIban,
            'publicHash' => $publicHash,
            'merchant' => $merchant,
        ];

        // Assign template variables
        $this->context->smarty->assign([
            'irispay_backend' => $this->module->getBackendUrl(),
            'irispay_payment_data_b64' => base64_encode(json_encode($paymentData)),
            'irispay_poll_url' => $this->context->link->getModuleLink('irispay', 'status', ['cart_id' => $cartId], true),
            'irispay_hookhash' => $hookHash,
            'irispay_userhash' => $userHash,
            'irispay_environment' => Configuration::get('IRISPAY_ENVIRONMENT', 'sandbox')
        ]);

        // Render the checkout component
        $this->setTemplate('module:irispay/views/templates/front/payment_checkout_v2.tpl');
    }
}
