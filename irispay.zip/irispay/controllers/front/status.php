<?php
/**
 * AJAX Status controller.
 * Returns JSON with order status and, when confirmed, the direct URL to redirect to.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class IrisPayStatusModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        header('Content-Type: application/json');

        $cartId = (int) Tools::getValue('cart_id');

        if ($cartId <= 0) {
            die(json_encode(['status' => 'pending']));
        }

        $id_order = Order::getIdByCartId($cartId);

        if ($id_order) {
            $order = new Order((int) $id_order);
            // PrestaShop's OrderConfirmationController validates against the ORDER's secure_key,
            // not necessarily the customer's secure_key, especially for guest checkout.

            $confirmUrl = $this->context->link->getPageLink(
                'order-confirmation',
                true,
                null,
                [
                    'id_cart' => $cartId,
                    'id_module' => (int) $this->module->id,
                    'id_order' => (int) $order->id,
                    'key' => $order->secure_key,
                ]
            );

            die(json_encode([
                'status' => 'success',
                'redirect' => $confirmUrl,
            ]));
        }

        die(json_encode(['status' => 'pending']));
    }
}
