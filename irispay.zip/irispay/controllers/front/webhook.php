<?php
/**
 * Webhook controller — IRIS Pay notifies this endpoint via GET request.
 * Registered via createhook API with optionalEvents: ['PAYMENT_AUTHORISED']
 *
 * Webhook URL: http://yourdomain.com/module/irispay/webhook
 * IRIS sends GET /?state=cart_{id} — the 'state' we set when creating the hook.
 *
 * Before creating the order, we verify the payment status via:
 *   GET {backendUrl}api/8/status/{hookHash}
 * Only status = CONFIRMED proceeds with order creation.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class IrisPayWebhookModuleFrontController extends ModuleFrontController
{
    public $ajax = true;

    /** Terminal failed statuses — no point retrying */
    const FAILED_STATUSES = ['REJECTED', 'FAILED'];

    /** Pending statuses — payment not yet settled */
    const PENDING_STATUSES = ['WAITING', 'SCA_REDIRECTED', 'CREATED', 'BULK_PROCESSED'];

    public function initContent()
    {
        // The 'state' query param we set when creating the hook = 'cart_{id}'
        $state = Tools::getValue('state', '');

        if (!preg_match('/^cart_(\d+)$/', $state, $matches)) {
            http_response_code(400);
            die('Invalid state');
        }

        $cartId = (int) $matches[1];
        $cart = new Cart($cartId);

        if (!Validate::isLoadedObject($cart)) {
            http_response_code(400);
            die('Cart not found');
        }

        // ---- Retrieve stored hookHash for this cart ---------------------
        $hookHash = Configuration::get('IRISPAY_HOOK_' . $cartId);
        if (!$hookHash) {
            http_response_code(400);
            die('Hook hash not found for cart');
        }

        // ---- Verify payment status via IRIS API -------------------------
        // $status = $this->module->getPaymentStatus($hookHash);
        $status = Tools::getValue('status');

        if (!$status) {
            // API call failed — respond 500 so IRIS will retry
            http_response_code(500);
            die('Status check failed');
        }

        if (in_array($status, self::FAILED_STATUSES)) {
            // Payment rejected/failed — acknowledge and stop
            http_response_code(200);
            die('PAYMENT_FAILED');
        }

        if (in_array($status, self::PENDING_STATUSES)) {
            // Not yet settled — return 200 so IRIS does not retry endlessly,
            // but also don't create the order yet
            http_response_code(200);
            die('PENDING');
        }

        if ($status !== 'CONFIRMED') {
            // Unknown status — safe fallback
            http_response_code(200);
            die('UNKNOWN_STATUS');
        }

        // ---- Status is CONFIRMED — create the order --------------------
        $existingOrders = Order::getByCartId($cartId);
        if (!empty($existingOrders)) {
            // Order already created (duplicate webhook) — idempotent OK
            http_response_code(200);
            die('OK');
        }

        $customer = new Customer($cart->id_customer);

        $this->module->validateOrder(
            $cartId,
            Configuration::get('PS_OS_PAYMENT'),
            (float) $cart->getOrderTotal(true, Cart::BOTH),
            $this->module->displayName,
            null,
            [
                'transaction_id' => Tools::getValue('paymentId', ''),
                'iris_status' => $status,
                'iris_state' => $state,
            ],
            (int) $cart->id_currency,
            false,
            $cart->secure_key
        );

        // Clean up stored hookHash
        Configuration::deleteByName('IRISPAY_HOOK_' . $cartId);

        http_response_code(200);
        die('OK');
    }
}
