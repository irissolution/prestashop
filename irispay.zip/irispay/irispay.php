<?php
/**
 * IRIS Pay Custom Payment Module
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class Irispay extends PaymentModule
{
    public function __construct()
    {
        $this->name = 'irispay';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
        $this->author = 'Infinno';
        $this->controllers = ['payment', 'confirm', 'webhook', 'status'];

        parent::__construct();

        $this->displayName = $this->l('Iris Pay Payment');
        $this->description = $this->l('Accept payments via IRIS Pay SDK.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return parent::install()
            && $this->registerHook('paymentOptions')
            && $this->registerHook('paymentReturn')
            && $this->registerHook('displayHeader')
            && Configuration::updateValue('IRISPAY_ENVIRONMENT', 'sandbox')
            && Configuration::updateValue('IRISPAY_API_KEY', '')
            && Configuration::updateValue('IRISPAY_SDK_VERSION', 'prod');
    }

    public function uninstall()
    {
        return parent::uninstall()
            && Configuration::deleteByName('IRISPAY_ENVIRONMENT')
            && Configuration::deleteByName('IRISPAY_API_KEY')
            && Configuration::deleteByName('IRISPAY_SDK_VERSION');
    }


    public function getContent()
    {
        $output = '';

        if (Tools::isSubmit('submitIrisPaySettings')) {
            $env = (string) Tools::getValue('IRISPAY_ENVIRONMENT');
            $apiKey = (string) Tools::getValue('IRISPAY_API_KEY');
            $sdkVersion = (string) Tools::getValue('IRISPAY_SDK_VERSION');

            Configuration::updateValue('IRISPAY_ENVIRONMENT', $env);
            Configuration::updateValue('IRISPAY_API_KEY', $apiKey);
            Configuration::updateValue('IRISPAY_SDK_VERSION', $sdkVersion);

            $output .= $this->displayConfirmation($this->l('Settings updated'));
        }

        return $output . $this->renderForm();
    }

    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitIrisPaySettings';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = [
            'fields_value' => $this->getConfigFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        ];

        return $helper->generateForm([$this->getConfigForm()]);
    }

    protected function getConfigForm()
    {
        return [
            'form' => [
                'legend' => [
                    'title' => $this->l('IRIS Pay Settings'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'select',
                        'label' => $this->l('Environment'),
                        'name' => 'IRISPAY_ENVIRONMENT',
                        'options' => [
                            'query' => [
                                ['id' => 'sandbox', 'name' => 'Sandbox'],
                                ['id' => 'live', 'name' => 'Live']
                            ],
                            'id' => 'id',
                            'name' => 'name'
                        ]
                    ],
                    [
                        'type' => 'select',
                        'label' => $this->l('SDK Version'),
                        'name' => 'IRISPAY_SDK_VERSION',
                        'options' => [
                            'query' => [
                                ['id' => 'prod', 'name' => 'Production (Iris Pay)'],
                                ['id' => 'dev', 'name' => 'Developer (Infn Dev)']
                            ],
                            'id' => 'id',
                            'name' => 'name'
                        ]
                    ],

                    [
                        'type' => 'text',
                        'label' => $this->l('API Key'),
                        'name' => 'IRISPAY_API_KEY',
                        'col' => 9,
                        'required' => true,
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                ],
            ],
        ];
    }

    protected function getConfigFormValues()
    {
        return [
            'IRISPAY_ENVIRONMENT' => Configuration::get('IRISPAY_ENVIRONMENT', 'sandbox'),
            'IRISPAY_API_KEY' => Configuration::get('IRISPAY_API_KEY', ''),
            'IRISPAY_SDK_VERSION' => Configuration::get('IRISPAY_SDK_VERSION', 'prod'),
        ];

    }

    public function getBackendUrl()
    {
        $env = Configuration::get('IRISPAY_ENVIRONMENT', 'sandbox');
        return $env === 'live' ? 'https://developer.irispay.bg/' : 'https://developer.sandbox.irispay.bg/';
    }

    public function getPayByClickBackendUrl()
    {
        $env = Configuration::get('IRISPAY_ENVIRONMENT', 'sandbox');
        return $env === 'live' ? 'https://paybyclick.irispay.bg/backend/' : 'https://dev.paybyclick.irispay.bg/backend/';
    }

    /**
     * Auth: Retrieve userHash from IRIS API
     */
    public function getUserHash($publicHash)
    {
        $url = rtrim($this->getBackendUrl(), '/') . '/api/8/signup/public';

        $payload = [
            'publicHash' => $publicHash
        ];

        PrestaShopLogger::addLog('[IRIS Pay] getUserHash Request: ' . $url . ' with body ' . json_encode($payload), 1);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'accept: application/json',
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 10
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($httpCode !== 200) {
            PrestaShopLogger::addLog('[IRIS Pay] getUserHash Failed. HTTP Code: ' . $httpCode . '. Response: ' . $response . '. CURL Error: ' . $error, 3);
            return false;
        }

        $data = json_decode($response, true);
        return isset($data['userHash']) ? $data['userHash'] : false;
    }

    /**
     * Hook Initiation: Retrieve hookHash from IRIS API
     */
    public function getHookHash($currency, $description, $orderId, $sum, $hookUrl)
    {
        $url = rtrim($this->getPayByClickBackendUrl(), '/') . '/payment/plugin/create';
        $apiKey = Configuration::get('IRISPAY_API_KEY');

        $payload = [
            'currency' => $currency,
            'description' => (string) $description,
            'key' => $apiKey,
            'orderId' => (string) $orderId,
            'sum' => (float) $sum,
            'hookUrl' => $hookUrl,
        ];

        PrestaShopLogger::addLog('[IRIS Pay] getHookHash Request: ' . $url . ' Payload: ' . json_encode($payload), 1);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'accept: application/json',
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 10
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($httpCode !== 200) {
            PrestaShopLogger::addLog('[IRIS Pay] getHookHash Failed. HTTP Code: ' . $httpCode . '. Response: ' . $response . '. CURL Error: ' . $error, 3);
            return false;
        }

        return json_decode($response, true);
    }

    /**
     * Check current status of a hook/payment
     */
    public function getPaymentStatus($hookHash)
    {
        $url = rtrim($this->getBackendUrl(), '/') . '/api/8/status/' . urlencode($hookHash);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'accept: application/json',
            ],
            CURLOPT_TIMEOUT => 10
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($httpCode !== 200) {
            PrestaShopLogger::addLog('[IRIS Pay] getPaymentStatus Failed. HTTP Code: ' . $httpCode . '. Response: ' . $response . '. CURL Error: ' . $error, 3);
            return false;
        }

        $data = json_decode($response, true);
        return isset($data['status']) ? $data['status'] : false;
    }

    public function hookDisplayHeader($params)
    {
        $sdkVersion = Configuration::get('IRISPAY_SDK_VERSION', 'prod');
        $jsUrl = 'https://websdk.irispay.bg/assets/irispay-ui/elements.js';
        $cssUrl = 'https://websdk.irispay.bg/assets/irispay-ui/styles.css';

        if ($sdkVersion === 'dev') {
            $jsUrl = 'https://websdk.infn.dev/assets/irispay-ui/elements.js';
            $cssUrl = 'https://websdk.infn.dev/assets/irispay-ui/styles.css';
        }


        // Add IRIS Pay SDK JS
        $this->context->controller->registerJavascript(
            'module-irispay-irispay-sdk',
            $jsUrl,
            ['server' => 'remote', 'position' => 'bottom', 'priority' => 150]
        );
        // Add IRIS Pay SDK CSS
        $this->context->controller->registerStylesheet(
            'module-irispay-irispay-sdk-css',
            $cssUrl,
            ['server' => 'remote', 'media' => 'all']
        );
    }


    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return [];
        }

        $paymentOption = new PaymentOption();
        $paymentOption->setCallToActionText($this->l('Плащане през IRIS Pay (Open Banking)'))
            ->setAction($this->context->link->getModuleLink($this->name, 'payment', [], true));

        return [$paymentOption];
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }

        $order = $params['order'];

        $this->smarty->assign([
            'shop_name' => $this->context->shop->name,
            'total_to_pay' => Tools::displayPrice($order->total_paid, new Currency($order->id_currency), false),
            'status' => 'ok',
            'id_order' => $order->id
        ]);

        return $this->display(__FILE__, 'views/templates/hook/payment_return.tpl');
    }
}
