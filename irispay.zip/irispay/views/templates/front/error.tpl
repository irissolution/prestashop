{extends file='page.tpl'}

{block name='page_title'}
  {l s='Payment Error' mod='irispay'}
{/block}

{block name='page_content'}
  <div class="alert alert-danger">
    <p>{$error}</p>
  </div>
  <a href="{$urls.pages.order}" class="btn btn-primary">
    {l s='Return to checkout' mod='irispay'}
  </a>
{/block}
