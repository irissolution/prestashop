{extends file='page.tpl'}

{block name='page_title'}
  {l s='Complete Your Payment' mod='irispay'}
{/block}

{block name='page_content'}

<link rel="stylesheet" href="{$irispay_sdk_css|escape:'html':'UTF-8'}" />

<div class="irispay-wrapper" style="max-width:600px; margin: 0 auto;">
  <h4>{l s='Pay securely via IRIS Pay (Open Banking)' mod='irispay'}</h4>
  <div id="irispay-container"></div>
</div>

<script src="{$irispay_sdk_js|escape:'html':'UTF-8'}"></script>
<script type="text/javascript">
  (function () {
    // Decode base64 JSON — avoids all Smarty/JS escaping issues
    var paymentDataStr = atob('{$irispay_payment_data_b64}');

    var paymentElement = document.createElement('irispay-component');
    var container      = document.getElementById('irispay-container');

    paymentElement.setAttribute('type',               'payment-data');
    paymentElement.setAttribute('show_bank_selector', 'true');
    paymentElement.setAttribute('payment_data',       paymentDataStr);
    paymentElement.setAttribute('hookhash',           '{$irispay_hookhash}');
    paymentElement.setAttribute('userhash',           '{$irispay_userhash}');
    paymentElement.setAttribute('backend',            '{$irispay_backend}');

    container.appendChild(paymentElement);
  })();
</script>

{/block}
