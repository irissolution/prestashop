{extends file="page.tpl"}

{block name="page_title"}
  {l s="Complete Your Payment" mod="irispay"}
{/block}

{block name="page_content"}

<div class="irispay-wrapper" style="max-width:600px; margin: 0 auto;">
  <h4>{l s="Pay securely via IRIS Pay (Open Banking)" mod="irispay"}</h4>
  <div id="irispay-container"></div>
</div>

<script type="text/javascript">
  (function () {
    var paymentDataStr = atob("{$irispay_payment_data_b64}");
    
    console.log('[IRIS Pay] Initializing V2 Script Engine...');

    var paymentElement = document.createElement("irispay-component");
    var container      = document.getElementById("irispay-container");

    paymentElement.setAttribute("type",               "payment-data");
    paymentElement.setAttribute("show_bank_selector", "true");
    paymentElement.setAttribute("payment_data",       paymentDataStr);
    paymentElement.setAttribute("hookhash",           "{$irispay_hookhash}");
    paymentElement.setAttribute("userhash",           "{$irispay_userhash}");
    paymentElement.setAttribute("backend",            "{$irispay_backend}");
    container.appendChild(paymentElement);

    // Setup URLs from Smarty variables
    var pollUrl = "{$irispay_poll_url nofilter}";
    
    // We recreate the error URL by swapping 'status' controller for 'confirm' and adding status=error
    var errorUrl = pollUrl.replace('status', 'confirm') + "&status=error";

    var isPolling = false;

    // The polling function
    function startPaymentVerificationPoll() {
        if (isPolling) return;
        isPolling = true;

        console.log('[IRIS Pay] Starting order verification poll...');
        
        // Show a loading message
        var loadingMsg = document.createElement('div');
        loadingMsg.innerHTML = '<br/><h5 style="text-align:center; color:#555;">Очакваме потвърждение от банката. Моля, изчакайте...</h5>';
        container.appendChild(loadingMsg);

        var pollTimer = setInterval(function() {
            fetch(pollUrl, { headers: { 'Cache-Control': 'no-cache' } })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    console.log('[IRIS Pay] Poll result:', data);
                    if (data.status === 'success' && data.redirect) {
                        clearInterval(pollTimer);
                        console.log('[IRIS Pay] Order confirmed! Redirecting...');
                        window.location.href = data.redirect;
                    }
                })
                .catch(function(err) {
                    console.error('[IRIS Pay] Poll fetch error:', err);
                });
        }, 3000); // Check every 3 seconds
    }

    // Listen for the final step event from the SDK (try both cases)
    var handleLastStep = function(e) {
        console.log('[IRIS Pay] lastStep event received:', e.detail || e);
        var detail = e.detail || {};
        if (detail.success === true || detail.success === 'true') {
            startPaymentVerificationPoll();
        } else {
            console.warn('[IRIS Pay] Payment failed or cancelled. Redirecting to error page.');
            if (errorUrl) {
                window.location.href = errorUrl;
            }
        }
    };

    paymentElement.addEventListener('lastStep', handleLastStep);
    paymentElement.addEventListener('laststep', handleLastStep);
    // Sometimes Angular standardizes to custom lowercase with 'on' prefix
    paymentElement.addEventListener('onlaststep', handleLastStep);

    // Fallback for iframe environments using postMessage
    window.addEventListener('message', function(event) {
        if (event.data && event.data.type === 'lastStep') {
            console.log('[IRIS Pay] lastStep (postMessage) received:', event.data);
            var payload = event.data.payload || {};
            if (payload.success === true) {
                startPaymentVerificationPoll();
            } else {
                console.warn('[IRIS Pay] Payment failed (postMessage). Redirecting to error page.');
                if (errorUrl) {
                    window.location.href = errorUrl;
                }
            }
        }
    });

  })();
</script>

{/block}
