{extends file='page.tpl'}

{block name='page_title'}
  {l s='Payment Processing' mod='irispay'}
{/block}

{block name='page_content'}
<div class="alert alert-info">
  <p>
    <strong>{l s='Your payment is being processed.' mod='irispay'}</strong>
  </p>
  <p>{l s='We are waiting for confirmation from IRIS Pay. Please do not close this page.' mod='irispay'}</p>
  <p>{l s='You will receive an email confirmation as soon as the payment is verified.' mod='irispay'}</p>
</div>
<a href="{$urls.pages.history}" class="btn btn-default">
  {l s='View my orders' mod='irispay'}
</a>
{/block}
