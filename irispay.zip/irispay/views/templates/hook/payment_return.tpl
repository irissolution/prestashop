<div class="alert alert-success">
  <p>{l s='Your payment has been received. Thank you!' mod='irispay'}</p>
  <p>{l s='Shop name:' mod='irispay'} <strong>{$shop_name|escape:'html':'UTF-8'}</strong></p>
</div>
