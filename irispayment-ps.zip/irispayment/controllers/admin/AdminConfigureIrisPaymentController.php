<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */
class AdminConfigureIrisPaymentController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->className = 'Configuration';
        $this->table = 'configuration';

        parent::__construct();

        if (empty(Currency::checkPaymentCurrencies($this->module->id))) {
            $this->warnings[] = $this->l('No currency has been set for this module.');
        }

        $this->fields_options = [
            $this->module->name => [
                'fields' => [
                    'iris_testmode' => [
                        'type' => 'bool',
                        'title' => $this->l('Test Mode'),
						'desc' => $this->l('Try the payment in test mode'),
                        'validation' => 'isBool',
                        'cast' => 'intval',
                        'required' => false,
                    ],
                    'iris_title' => [
                        'type' => 'text',
                        'title' => $this->l('Title'),
                        'required' => true,
                    ],
                    'iris_description' => [
                        'type' => 'text',
                        'title' => $this->l('Description'),
                        'desc' => $this->l('This controls the description which the user sees during checkout.'),
                        'required' => true,
                    ],
                    'iris_merchant_key' => [
                        'type' => 'text',
                        'title' => $this->l('Merchant Key'),
						'desc' => $this->l('Your Merchant Key, obtained from your IRIS Solutions, Merchant portal account.'),
                        'required' => true,
                    ],
                    'iris_merchant_iban' => [
                        'type' => 'text',
                        'title' => $this->l('Merchant Account (IBAN)'),
						'desc' => $this->l('Your Merchant Account, obtained from your IRIS Solutions, Merchant portal account.'),
                        'required' => true,
                    ],
                    'iris_short_descr' => [
                        'type' => 'text',
                        'title' => $this->l('Short Description of the payment'),
                        'desc' => $this->l('Will be present in the fund transfer form of the bank in the description placeholder, up to 34 symbols.'),
                        'required' => true,
                    ],
                    'iris_long_descr' => [
                        'type' => 'text',
                        'title' => $this->l('Full Description of the payment'),
                        'desc' => $this->l('Will be present only in the IRIS Solutions systems, up to 240 symbols.'),
                        'required' => true,
						'default' => 'Payment at '
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                ],
            ],
        ];
    }
}
