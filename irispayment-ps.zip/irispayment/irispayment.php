<?php

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class IrisPayment extends PaymentModule
{
    const MODULE_ADMIN_CONTROLLER = 'AdminConfigureIrisPayment';
    const HOOKS = [
        'paymentOptions',
    ];

    public function __construct()
    {
        $this->name = 'irispayment';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'Iris Solutions';
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
        $this->ps_versions_compliancy = [
            'min' => '1.7',
            'max' => _PS_VERSION_,
        ];
        $this->controllers = [
            'account',
            'cancel',
            'external',
            'validation',
        ];

        parent::__construct();

        $this->displayName = $this->l('IRIS Solutions - Pay by Bank');
        $this->description = $this->l('"Pay by Bank" for PrestaShop gives your store the flexibility to make "account-to-account" payments. Activating the extension gives customers a choice of more than 40 banks and payment institutions.');
    }

	public function handleIpnNotification($postData) {
		die('done');
	}


    /**
     * @return bool
     */
    public function install()
    {
        return (bool) parent::install()
			&& (bool) $this->registerHook(static::HOOKS)
            && $this->installTabs();
    }

    /**
     * @return bool
     */
    public function uninstall()
    {
        return (bool) parent::uninstall()
            && $this->uninstallTabs();
    }

    /**
     * Module configuration page
     */
    public function getContent() {
        $this->installTabs();
        Tools::redirectAdmin($this->context->link->getAdminLink(static::MODULE_ADMIN_CONTROLLER));
    }

    /**
     * @param array $params
     *
     * @return array Should always return an array
     */
    public function hookPaymentOptions(array $params)
    {
        /** @var Cart $cart */
        $cart = $params['cart'];

        if (false === Validate::isLoadedObject($cart) || false === $this->checkCurrency($cart)) {
            return [];
        }

        $paymentOptions = [];
        $paymentOptions[] = $this->getExternalPaymentOption($cart);

        return $paymentOptions;
    }

    public function hookDisplayAdminOrderLeft(array $params)
    {
        if (empty($params['id_order'])) {
            return '';
        }

        $order = new Order((int) $params['id_order']);

        if (false === Validate::isLoadedObject($order) || $order->module !== $this->name) {
            return '';
        }

        $this->context->smarty->assign([
            'moduleName' => $this->name,
            'moduleDisplayName' => $this->displayName,
            'moduleLogoSrc' => $this->getPathUri() . 'logo.png',
        ]);

        return $this->context->smarty->fetch('module:irispayment/views/templates/hook/displayAdminOrderLeft.tpl');
    }

    /**
     * Check if currency is allowed in Payment Preferences
     *
     * @param Cart $cart
     *
     * @return bool
     */
    private function checkCurrency(Cart $cart)
    {
        $currency_order = new Currency($cart->id_currency);
        /** @var array $currencies_module */
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (empty($currencies_module)) {
            return false;
        }

        foreach ($currencies_module as $currency_module) {
            if ($currency_order->id == $currency_module['id_currency']) {
                return true;
            }
        }

        return false;
    }

    /**
     * Factory of PaymentOption for External Payment
     *
     * @return PaymentOption
     */
    private function getExternalPaymentOption(Cart $cart) {
		$currency = new Currency($cart->id_currency);
		$moduleUrl = Context::getContext()->link->getModuleLink('irispayment', 'irispayment', array('controller' => 'handleIpnNotification'), null, null, null, (Configuration::get('PS_SSL_ENABLED')));
		$ipnUrl = $moduleUrl.'/?fc=module&module=irispayment&controller=irispayment&action=handleIpnNotification';
		$args = [
			'currency'=>$currency->iso_code,
			'hookUrl'=>$ipnUrl,
			'name'=>Configuration::get('iris_short_descr'),
			'description'=>Configuration::get('iris_long_descr'),
			//'redirectUrl'=>$this->get_return_url($order),
			'orderId'=>$cart->id,
			'sum'=>$cart->getOrderTotal(),
			'toIban'=>Configuration::get('iris_merchant_iban'),
			'lang'=>'bg'
		];

		if (Configuration::get('iris_testmode')) $url = 'https://payperclick.infn.dev/backend/payment/external/';
		else $url = 'https://paybyclick.irispay.bg/backend/payment/external/';
		$resp = $this->HTTPPostJSON($url.Configuration::get('iris_merchant_key'), $args);
		//print_r($resp);
		$url = '';
		$resp = json_decode($resp);
		if (isset($resp->paymentLink)) {
			$url = $resp->paymentLink;
		}

        $externalOption = new PaymentOption();
        $externalOption->setModuleName($this->name);
        $externalOption->setCallToActionText(Configuration::get('iris_title'));
        $externalOption->setAction($url);
        $externalOption->setInputs([
            'token' => [
                'name' => 'token',
                'type' => 'hidden',
                'value' => '[5cbfniD+(gEV<59lYbG/,3VmHiE<U46;#G9*#NP#X.FA§]sb%ZG?5Q{xQ4#VM|7',
            ],
        ]);
        $externalOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/paybybank.png'));
        return $externalOption;
    }


	private function HTTPPostJSON($url, $postdata=0) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		if (is_array($postdata)) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postdata));
		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
	}


    /**
     * Install Tabs
     *
     * @return bool
     */
    public function installTabs()
    {
        if (Tab::getIdFromClassName(static::MODULE_ADMIN_CONTROLLER)) {
            return true;
        }

        $tab = new Tab();
        $tab->class_name = static::MODULE_ADMIN_CONTROLLER;
        $tab->module = $this->name;
        $tab->active = true;
        $tab->id_parent = -1;
        $tab->name = array_fill_keys(
            Language::getIDs(false),
            $this->displayName
        );

        return (bool) $tab->add();
    }

    /**
     * Uninstall Tabs
     *
     * @return bool
     */
    public function uninstallTabs()
    {
        $id_tab = (int) Tab::getIdFromClassName(static::MODULE_ADMIN_CONTROLLER);

        if ($id_tab) {
            $tab = new Tab($id_tab);

            return (bool) $tab->delete();
        }

        return true;
    }
}
