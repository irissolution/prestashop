<?php
global $_MODULE;
$_MODULE = [
	'Test Mode' => 'TTTT'
];
